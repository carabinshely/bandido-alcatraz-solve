"""Verify exported source bytes, recorded geometry, legal moves and V4 scores."""
import hashlib
import importlib.util
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
for name,digest in json.loads((HERE/'SHA256SUMS.json').read_text()).items():
    assert hashlib.sha256((HERE/name).read_bytes()).hexdigest() == digest, name
sys.path.insert(0,str(HERE/'src'))
from bandido_alcatraz.worker32.inputs import accepted_cards, reconstruct
from bandido_alcatraz.worker32.evidence import canonical, observation, move
from bandido_alcatraz.moves import Move, Action
from bandido_alcatraz.policies import BoundedMergeV4Policy
from bandido_alcatraz.strategy import move_features_no_draw, preview_move_without_draw, score_features

e=json.loads((HERE/'player-example.json').read_text(encoding='utf-8'))
# The exported snapshot is already whitelisted; reconstruct also compares every
# field to canonical engine serialization after replaying public placements.
class SnapshotParser:
    @staticmethod
    def validate_observation(v):
        assert set(v)=={'board','collected_equipment','exit_placed','exit_seen','hand',
                       'player_index','raincoats','ropes','set_aside_unplayable','setup','turns'}

assert hashlib.sha256(canonical(e['original'])).hexdigest()==e['source_snapshot_sha256']
o=reconstruct(e['original'],accepted_cards(HERE/'data'),SnapshotParser)
w=BoundedMergeV4Policy(setup_weight=250).weights
legal=o.legal_moves()
assert len(legal)==e['legal_move_count']==27
scores=[score_features(move_features_no_draw(o,m),w) for m in legal]
tier=[move(m) for m,s in zip(legal,scores) if s==max(scores)]
assert tier==e['primary_tier'] and len(tier)==4 and max(scores)==0
for c in e['choices']:
    raw=c['move'];m=Move(Action(raw['action']),raw['hand_index'],tuple(raw['origin']),raw['quarter_turns'])
    assert m in legal
    assert score_features(move_features_no_draw(o,m),w)==c['score']
    after=preview_move_without_draw(o,m).successor
    assert canonical(observation(after.observation()))==canonical(c['observation'])
print('PASS: 27 legal moves; A=0 (one of 4 maxima); B=-21800; A open=5 water=0; B open=3 water=1.')

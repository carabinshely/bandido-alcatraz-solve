Bandido Alcatraz: one recorded public position, not a new simulation.
Requires Python 3.11+. No pip dependencies or network.
Extract this ZIP. Run: py -3.11 verify_example.py
Expected: PASS: 27 legal moves; A=0 (one of 4 maxima); B=-21800; A open=5 water=0; B open=3 water=1.
No hidden draw order or recorded historical choice is included.
The 45/400 full-game baseline is a separate experiment, not reproduced by this single-position check.
